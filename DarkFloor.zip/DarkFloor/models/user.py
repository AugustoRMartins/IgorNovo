class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

users = {
    "admin": User("admin", "senha123"),
    "usuario": User("usuario", "senha123"),
}
