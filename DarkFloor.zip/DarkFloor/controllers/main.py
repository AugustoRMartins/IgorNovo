from flask import Blueprint, render_template, request, session
from functools import wraps

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return 'Tu não ta logado fi da peste', 401
        return f(*args, **kwargs)
    return decorated_function

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('search.html')

@main.route('/search', methods=['POST'])
def search():
    query = request.form.get('query')
    return render_template('search.html', query=query)

@main.route('/logado')
@login_required
def logado():
    username = session.get('username')  
    return render_template('logado.html', username=username)